<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário PHP</title>
</head>
<body>
    <h2>Formulário PHP</h2>
    <form action="processa_formulario.php" method="post">
        <label for="nome">Nome:</label>
        <input type="text" name="nome" required>

        <br>

        <label for="email">Email:</label>
        <input type="email" name="email" required>

        <br>

        <input type="submit" value="Enviar">
    </form>
</body>
</html>
